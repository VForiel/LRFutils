# LFRutils

This is a custom library for dev by myself and for myself (and some colleagues).
If you find something cool in this lib, you can freely use it, copy it, modify it, share it, whatever you want.
If you publish it somewhere, please be kind to at least credit me ;)

## -> [Go to Documentation](https://lrfutils.rtfd.io)